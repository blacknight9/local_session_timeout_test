package com.example.local_session_timeout_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
